let myName=document.querySelector("#myName")
let info=prompt("Adınızı Giriniz:")
myName.innerHTML=`${info}`

let saat=document.querySelector("#myClock")

function zaman(){
    saat.innerHTML=`${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}`
    
}

setInterval(zaman,1000)







